# Surge Agent

![lint](https://github.com/voltagecloud/agent/actions/workflows/golang-ci.yml/badge.svg)
![test](https://github.com/voltagecloud/agent/actions/workflows/test.yml/badge.svg)
![release](https://github.com/voltagecloud/agent/actions/workflows/release.yml/badge.svg)

## Download
The agent version you download and install depends on the verison of LND that you run on your node.
For LND versions `v0.14.3-beta` and lower, use agent version `v0.4.9` or lower.
For LND versions `v0.15.0-beta.rc1` or higher, use agent version `0.5.0` or higher.

- Mac (
  [x86_64](https://github.com/voltagecloud/agent/releases/download/v0.1.0/agent_0.1.0_Darwin_x86_64.tar.gz),
  [arm64](https://github.com/voltagecloud/agent/releases/download/v0.1.0/agent_0.1.0_Darwin_arm64.tar.gz)
 )
- Linux (
  [x86_64](https://github.com/voltagecloud/agent/releases/download/v0.1.0/agent_0.1.0_Linux_x86_64.tar.gz),
  [arm64](https://github.com/voltagecloud/agent/releases/download/v0.1.0/agent_0.1.0_Linux_arm64.tar.gz),
)
- Windows (
  [x86_64](https://github.com/voltagecloud/agent/releases/download/v0.1.0/agent_0.1.0_Windows_x86_64.tar.gz),
  [i386](https://github.com/voltagecloud/agent/releases/download/v0.1.0/agent_0.1.0_Windows_i386.tar.gz)
)

Alternative architectures and older version binaries can be found in the [GitHub releases](https://github.com/voltagecloud/agent/releases)

## Run

Running Surge requires the user to run a lightning node either on the Voltage platform or on their local machine.

The program can be run as a binary: `./server` (this is the name of the binary file available in our release downloads) or from the code with: `go run cmd/main.go`.
The flags are to be passed inline with either of these methods of running. 

Example:

`go run cmd/main.go  --lnd.host=voltage-mynode.voltageapp.io --lnd.macaroon-path=/home/custom-spot/readonly.macaroon --lnd.network=testnet --registration-endpoint=http://some-site/register --consumer-endpoint=http://some-site/consume --api-key=abcdef123456`
## Configuration
The agent can be configured via a config file, command line flags, or a hybrid approach using both. Command line flags take precedence over values set in the config file. Running with the `init` option uses a command line prompt to have you enter in values and generates a config file to `/your-home-dir/.surge/surge.conf`. Additionally, using the `sample-agent.conf` in the root of this repo can be used as a template to build out a config file. Fill out the required and any optional fields, and save the file to either the default location (`/your-home-dir/.surge/surge.conf`) or pass in the location with the `--config` flag from the command line.

Many of the default values are set to the defaults set by LND (namely install locations and files). Check the defaults below to determine if they match your setup or if configuring these values will be necessary.

If you are connecting the agent to a Voltage node, you can obtain the host and Readonly Macaroon for your node on the Voltage website. The `host` value can be found in the Voltage node dashboard under "API Endpoint". The Readonly Macaroon can be obtained from the Voltage dashbaord's "Connect" tab and downloading either the base64 or hex Readonly Macaroon, either will work.

If you are not using a Voltage node, a TLS cert will be required. The default for `lnd.tls-cert-path` will be `/your-home-dir/.lnd/tls.cert`. Configure this accordingly with where your TLS Cert file is located.

The `api-key`, `consumer-endpoint`, and `registration-endpoint` have no default values and are required to be configured.

NOTE: The default config values will use default LND flavored values and not Voltage flavored defaults. If you are connecting this agent to a Voltage node, ensure to configure `host`, `lnd.macaroon-path`, and `lnd.network` in addition to  `api-key`, `consumer-endpoint`, and `registration-endpoint`.

### Command line arguments

```sh
Usage:
  main [OPTIONS] [init]

Application Options:
      --api-key=                                                 (REQUIRED) API Key received from the Voltage Platform
      --consumer-endpoint=                                       (REQUIRED) Url to service listening for agent data
      --registration-endpoint=                                   (REQUIRED) URL to register agent with ingestion service
      --config=                                                  Location of the config File (default: /your-home-dir/.surge/surge.conf)
      --log-file=                                                Location of the Surge log file. Uses stdout if not specified
      --log-level=[debug|info|warning|error]                     Log Level for the agent's logging system (not to be confused with the node's log level) (default: info)
      --surge-dir=                                               Root directory to store config files and database (default: /your-home-dir/.surge)
      --node=[lnd|sensei]                                        Type of node this agent is for (default: lnd)
      --disable-transactions                                     Tells Surge to not send data about invoices, payments, transactions, and htlcs
      --disable-logging                                          Tells Surge to not upload the log file
      --disable-backup                                           Tells Surge to not perform backups of the node
  -v, --version                                                  Displays the version and exists

lnd:
      --lnd.host=                                                Endpoint for LND (default: 127.0.0.1:10009)
      --lnd.macaroon-path=                                       Path of the macaroon file (note: only a macaroon with read privileges is necessary) (default:
                                                                 /your-home-dir/.lnd/data/chain/bitcoin/mainnet/readonly.macaroon)
      --lnd.tls-cert-path=                                       Path of the TLS certificate (default: /your-home-dir/.lnd/tls.cert)                                                           
      --lnd.network=[mainnet|testnet]                            The bitcoin network. Changing this won't modify the paths of other flags. (default: mainnet)
      --lnd.log-file=                                            Location of the LND Log File (default: /your-home-dir/.lnd/logs/bitcoin/mainnet/lnd.log)
      --lnd.log-level=[trace|debug|info|warn|error|critical|off] Log level to capture from LND. Each level in the list is inclusive of the levels after it. (i.e. info will yield info, warn, error, and
                                                                 critical logs) (default: debug)
      --lnd.rpc-filter-enabled                                   When enabled the RPCMiddleware events generated by the agent's --lnd.macaroonpath's macaroon file are going to be filtered out

sensei:
      --sensei.host=                                             Endpoint for Sensei
      --sensei.macaroon-path=                                    Path of the macaroon file
      --sensei.network=                                          The bitcoin network
      --sensei.log-file=                                         Location of the Sensei Log File

OS:
      --os.disk=                                                 The disk to perform monitor on. Available disks are: ["loop0" "loop1" "loop10" "loop11" "loop12" "loop13" "loop14" "loop15" "loop16"
                                                                 "loop17" "loop18" "loop19" "loop2" "loop20" "loop21" "loop22" "loop23" "loop24" "loop25" "loop26" "loop27" "loop28" "loop29" "loop3"
                                                                 "loop30" "loop4" "loop5" "loop6" "loop7" "loop8" "loop9" "nvme0n1" "nvme0n1p1" "nvme0n1p2" "nvme0n1p3"]

Help Options:
  -h, --help                                                     Show this help message

Available commands:
  init  Initializes a new config



```

## Development

Although we follow a standard go development, we tried to automate some tasks
using `go:generate`, namely protobuf generation and stringify some enums via
[stringer](https://pkg.go.dev/golang.org/x/tools/cmd/stringer).
So make sure to run `go generate ./...` before pushing any changes.

# Run with Sensei

A Bitcoin node needs to be running. A Sensei node needs to be running.

In the config file, set these options for mainnet:

```
[Application Options]
node=sensei

[sensei]
sensei.host=http://127.0.0.1:5401
sensei.macaroonpath=~/.sensei/bitcoin/<node-id-here>/data/admin.macaroon
sensei.network=mainnet
sensei.logfile=~/.sensei/bitcoin/<node-id-here>/data/logs/logs.txt
```
